// RVTester.java

package com.seagatesoftware.img.RVTester;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.beans.*;
import java.util.*;
import java.net.*;

import com.seagatesoftware.img.ReportViewer.ReportViewer;
import com.seagatesoftware.img.ReportViewer.ReportViewerBean;
import com.seagatesoftware.img.ReportViewer.ViewChangeListener;
import com.seagatesoftware.img.ReportViewer.ViewChangeEvent;
import com.seagatesoftware.img.ReportViewer.ServerRequestListener;
import com.seagatesoftware.img.ReportViewer.ServerRequestEvent;

public class RVTester extends Applet
    implements PropertyChangeListener, ViewChangeListener, ServerRequestListener
{
	private transient boolean standAlone = false;

    

    private transient ActionListener closeViewButtonActionListener;
    private transient ActionListener firstPageButtonActionListener;
    private transient ActionListener prevPageButtonActionListener;
    private transient ActionListener nextPageButtonActionListener;
    private transient ActionListener lastPageButtonActionListener;
    private transient ActionListener goToPageButtonActionListener;
    private transient ActionListener stopButtonActionListener;
    private transient ActionListener printButtonActionListener;
    private transient ActionListener exportButtonActionListener;
    private transient ActionListener refreshButtonActionListener;
    private transient ActionListener searchForTextButtonActionListener;
    private transient ActionListener searchAgainButtonActionListener;

	public static void main (String args [])
	{
		Frame frame = new Frame ("RVTester");
		frame.setLayout(new BorderLayout());
        frame.setVisible (true);
		frame.setVisible (false);
		frame.setSize (frame.insets ().left + frame.insets ().right  + 600,
					   frame.insets ().top  + frame.insets ().bottom + 400);

		RVTester rvTester = new RVTester ();
		frame.addWindowListener (new WindowAdapter ()
        {
            public void windowClosing (WindowEvent e)
            {
				System.exit (0);
            }
        });
		frame.add (rvTester, BorderLayout.CENTER);
		
		rvTester.standAlone = true;
		rvTester.init ();
		rvTester.start ();

        frame.setVisible (true);
	} 

	public RVTester ()
	{
        setBackground (new Color (255, 255, 192));
	}

    public Insets insets ()
    {
        return new Insets (5, 5, 5, 5);
    }

    public Insets getInsets ()
    {
        return insets ();
    }

	public String getAppletInfo ()
	{
		return "Name: RVTester\r\n" +
		       "Author: Marko Udovicic";
	}

	public void init ()
	{
		//{{INIT_CONTROLS
		setLayout(new BorderLayout(0,0));
		if(standAlone)
    		setSize(662,400);
		setBackground(new Color(12632256));
		labelPanel = new java.awt.Panel();
		labelPanel.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
		labelPanel.setBounds(0,-23,662,10);
		add("South", labelPanel);
		showViewerProperty = new java.awt.Button();
		showViewerProperty.setActionCommand("button");
		showViewerProperty.setLabel("Viewer Property and Event Page...");
		showViewerProperty.setBounds(-46,0,197,23);
		showViewerProperty.setBackground(new Color(12632256));
		labelPanel.add(showViewerProperty);
		controlsPanel = new java.awt.Panel();
		controlsPanel.setLayout(new FlowLayout(FlowLayout.CENTER,0,0));
		controlsPanel.setBounds(0,0,662,0);
		add("North", controlsPanel);
		closeViewButton = new java.awt.Button();
		closeViewButton.setLabel("Close View");
		closeViewButton.setBounds(2,0,76,23);
		closeViewButton.setBackground(new Color(12632256));
		controlsPanel.add(closeViewButton);
		closeViewButton.setEnabled(false);
		firstPageButton = new java.awt.Button();
		firstPageButton.setLabel("|<");
		firstPageButton.setBounds(78,0,24,23);
		controlsPanel.add(firstPageButton);
		firstPageButton.setEnabled(false);
		prevPageButton = new java.awt.Button();
		prevPageButton.setLabel("<");
		prevPageButton.setBounds(22,23,21,23);
		controlsPanel.add(prevPageButton);
		prevPageButton.setEnabled(false);
		pageField = new java.awt.TextField(5);
		pageField.setText("     ");
		pageField.setBounds(43,23,39,23);
		controlsPanel.add(pageField);
		goToPageButton = new java.awt.Button();
		goToPageButton.setActionCommand("Page...");
		goToPageButton.setLabel("<-Page");
		goToPageButton.setBounds(2,46,54,23);
		controlsPanel.add(goToPageButton);
		goToPageButton.setEnabled(false);
		nextPageButton = new java.awt.Button();
		nextPageButton.setLabel(">");
		nextPageButton.setBounds(56,46,21,23);
		controlsPanel.add(nextPageButton);
		nextPageButton.setEnabled(false);
		lastPageButton = new java.awt.Button();
		lastPageButton.setLabel(">|");
		lastPageButton.setBounds(77,46,24,23);
		controlsPanel.add(lastPageButton);
		lastPageButton.setEnabled(false);
		stopButton = new java.awt.Button();
		stopButton.setLabel("Stop");
		stopButton.setBounds(3,69,39,23);
		controlsPanel.add(stopButton);
		stopButton.setEnabled(false);
		refreshButton = new java.awt.Button();
		refreshButton.setLabel("Refresh");
		refreshButton.setBounds(42,69,58,23);
		controlsPanel.add(refreshButton);
		refreshButton.setEnabled(false);
		printButton = new java.awt.Button();
		printButton.setLabel("Print");
		printButton.setBounds(8,92,39,23);
		controlsPanel.add(printButton);
		printButton.setEnabled(false);
		exportButton = new java.awt.Button();
		exportButton.setLabel("Export");
		exportButton.setBounds(47,92,48,23);
		controlsPanel.add(exportButton);
		exportButton.setEnabled(false);
		searchForTextButton = new java.awt.Button();
		searchForTextButton.setActionCommand("Search...");
		searchForTextButton.setLabel("Search->");
		searchForTextButton.setBounds(20,115,64,23);
		controlsPanel.add(searchForTextButton);
		searchForTextButton.setEnabled(false);
		searchField = new java.awt.TextField(5);
		searchField.setText("           ");
		searchField.setBounds(23,138,57,23);
		controlsPanel.add(searchField);
		reportPanel = new java.awt.Panel();
		reportPanel.setLayout(new BorderLayout(100,100));
		reportPanel.setBounds(0,23,662,344);
		add("Center", reportPanel);
		try {
		//ClassLoader cl = Class.forName("com.seagatesoftware.img.ReportViewer.ReportViewerBean").getClassLoader();
		//reportViewer = (com.seagatesoftware.img.ReportViewer.ReportViewerBean) java.beans.Beans.instantiate(cl, "com.seagatesoftware.img.ReportViewer.ReportViewerBean");
		reportViewer = new ReportViewerBean();
		reportViewer.setLayout(new BorderLayout(0,0));
		reportViewer.setBounds(0,0,104,-46);
		reportViewer.setForeground(new Color(0));
		reportViewer.setBackground(new Color(12632256));
		reportPanel.add("Center", reportViewer);
		reportViewer.start();
		} catch (Exception e) { }
		//}}
		propertyWindow = new RVTesterProperty(this, "Report Viewer Bean Properties and Events");
	    reportViewer.setName("Report Viewer Bean");







		//{{REGISTER_LISTENERS
		SymMouse aSymMouse = new SymMouse();

		showViewerProperty.addActionListener(aSymMouse);

		//}}
	}

	public void start ()
	{
		attachToReportViewer();
		updateButtons ();
	}
	
	public void stop ()
	{
	    System.out.println("applet is stopped");
	}

	public void destroy ()
	{
	    System.out.println("applet is destroyed");
        detachFromReportViewer ();

        closeViewButton = null;
        propertyWindow.setVisible (false);
        propertyWindow = null;
        firstPageButton = null;
        prevPageButton = null;
        nextPageButton = null;
        lastPageButton = null;
        goToPageButton = null;

        stopButton = null;

        refreshButton = null;

        printButton = null;
    
        searchForTextButton = null;
       
        searchString = "";

        removeAll ();
	}

    private Frame getFrame ()
    {
        for (Container parent = getParent (); parent != null; parent = parent.getParent ())
            if (parent instanceof Frame)
                return (Frame) parent;

        return null;
    }

    private ReportViewerBean findReportViewer (String reportViewerName,
                                               Container container)
    {
        if (container == null)
            return null;
        
        int nComponents = container.getComponentCount ();
        for (int componentN = 0; componentN < nComponents; ++componentN)
        {
            Component component = container.getComponent (componentN);
            if (reportViewerName.equals (component.getName ()) &&
                component instanceof ReportViewerBean)
                return (ReportViewerBean) component;
        }

        for (int componentN = 0; componentN < nComponents; ++componentN)
        {
            Component component = container.getComponent (componentN);
            if (component instanceof Container)
            {
                ReportViewerBean reportViewer =
                    findReportViewer (reportViewerName, (Container) component);
                if (reportViewer != null)
                    return reportViewer;
            }
        }

        return null;
    }


	
    private void attachToReportViewer ()
    {
		reportViewer.addPropertyChangeListener (this);
		reportViewer.addViewChangeListener (this);
		reportViewer.addServerRequestListener (this);

        closeViewButtonActionListener =
            new ActionListener ()
            {
                public void actionPerformed (ActionEvent e)
                {
                    reportViewer.closeCurrentView ();
					updateButtons ();
                }
            };
        closeViewButton.addActionListener (closeViewButtonActionListener);

        firstPageButtonActionListener =
            new ActionListener ()
            {
                public void actionPerformed (ActionEvent e)
                {
                    reportViewer.showPage (1);
					updateButtons ();
                }
            };
        firstPageButton.addActionListener (firstPageButtonActionListener);

        prevPageButtonActionListener =
            new ActionListener ()
            {
                public void actionPerformed (ActionEvent e)
                {
                    reportViewer.showPage (reportViewer.getCurrentPageNumber () - 1);
					updateButtons ();
                }
            };
        prevPageButton.addActionListener (prevPageButtonActionListener);

        nextPageButtonActionListener =
            new ActionListener ()
            {
                public void actionPerformed (ActionEvent e)
                {
                    reportViewer.showPage (reportViewer.getCurrentPageNumber () + 1);
					updateButtons ();
                }
            };
        nextPageButton.addActionListener (nextPageButtonActionListener);

        lastPageButtonActionListener =
            new ActionListener ()
            {
                public void actionPerformed (ActionEvent e)
                {
                    reportViewer.showLastPage ();
					updateButtons ();
                }
            };
        lastPageButton.addActionListener (lastPageButtonActionListener);

       goToPageButtonActionListener =
            new ActionListener ()
            {
                public void actionPerformed (ActionEvent e)
                {
                    
                  String pageN = pageField.getText();
                  int temp;
                  try{
                    temp =  Integer.parseInt (pageN.trim());
                  }
                  catch(NumberFormatException enum)
                  {
                    temp = 1;
                  }
				 
                 reportViewer.showPage(temp);
                 updateButtons();
                 }
            };
        goToPageButton.addActionListener (goToPageButtonActionListener);
		

        stopButtonActionListener =
            new ActionListener ()
            {
                public void actionPerformed (ActionEvent e)
                {
                    reportViewer.stopAllCommands ();
					updateButtons ();
				}
            };
        stopButton.addActionListener (stopButtonActionListener);

        printButtonActionListener =
            new ActionListener ()
            {
                public void actionPerformed (ActionEvent e)
                {
                    reportViewer.printView ();
					updateButtons ();
                }
            };
        printButton.addActionListener (printButtonActionListener);
        
        exportButtonActionListener =
            new ActionListener ()
            {
                public void actionPerformed (ActionEvent e)
                {
                    RVSelectFile tmpSelectFile;
                    tmpSelectFile = new RVSelectFile(new Frame(), true, reportViewer);
                    tmpSelectFile.show();
					updateButtons ();
                }
            };
        exportButton.addActionListener (exportButtonActionListener);


        refreshButtonActionListener =
            new ActionListener ()
            {
                public void actionPerformed (ActionEvent e)
                {
                    reportViewer.refreshReport ();
					updateButtons ();
                }
            };
        refreshButton.addActionListener (refreshButtonActionListener);

        searchForTextButtonActionListener =
            new ActionListener ()
            {
                public void actionPerformed (ActionEvent e)
                {
            
					
					searchString = searchField.getText();
				   
					
                   
                   if (searchString.length () > 0)
                       //reportViewer.searchForText (searchString.trim(), true, caseSearch.getState());
                       reportViewer.searchForText (searchString.trim(), true, false);
                   // System.out.println("This is the case: " + String.valueOf(caseSearch.getState()));
                    updateButtons ();
                }
            };
        searchForTextButton.addActionListener (searchForTextButtonActionListener);
		

       
    }

    private void detachFromReportViewer ()
    {
        if (reportViewer == null)
            return;

		reportViewer.removePropertyChangeListener (this);
		reportViewer.removeViewChangeListener (this);
		reportViewer.removeServerRequestListener (this);

        closeViewButton.removeActionListener (closeViewButtonActionListener);
        closeViewButtonActionListener = null;

        firstPageButton.removeActionListener (firstPageButtonActionListener);
        firstPageButtonActionListener = null;

        prevPageButton.removeActionListener (prevPageButtonActionListener);
        prevPageButtonActionListener = null;

        nextPageButton.removeActionListener (nextPageButtonActionListener);
        nextPageButtonActionListener = null;

        lastPageButton.removeActionListener (lastPageButtonActionListener);
        lastPageButtonActionListener = null;

        goToPageButton.removeActionListener (goToPageButtonActionListener);
        goToPageButtonActionListener = null;

        stopButton.removeActionListener (stopButtonActionListener);
        stopButtonActionListener = null;

        printButton.removeActionListener (printButtonActionListener);
        printButtonActionListener = null;

        refreshButton.removeActionListener (refreshButtonActionListener);
        refreshButtonActionListener = null;

        searchForTextButton.removeActionListener (searchForTextButtonActionListener);
        searchForTextButtonActionListener = null;

       
        reportViewer = null;
    }

    public void updateButtons ()
    {
        int curPageN = getCurrentPageNumber ();
        int lastPageN = getLastPageNumber ();
        boolean lastPageNKnown = isLastPageNumberKnown ();

        if (closeViewButton != null)
            closeViewButton.setEnabled (getCanCloseCurrentView ());

        if (firstPageButton != null)
            firstPageButton.setEnabled (curPageN > 1);

        if (prevPageButton != null)
            prevPageButton.setEnabled (curPageN > 1);

        if (nextPageButton != null)
            nextPageButton.setEnabled (curPageN > 0 && (!lastPageNKnown || curPageN < lastPageN));

        if (lastPageButton != null)
            lastPageButton.setEnabled (curPageN > 0 && (!lastPageNKnown || curPageN < lastPageN));

        if (goToPageButton != null)
            goToPageButton.setEnabled (curPageN > 0);

        if (stopButton != null)
            stopButton.setEnabled (isBusy ());

        if (refreshButton != null)
            refreshButton.setEnabled (curPageN > 0);

        if (printButton != null)
            printButton.setEnabled (isPrintingPossible () && curPageN > 0);
        
        if (exportButton != null)
            exportButton.setEnabled (isExportingPossible () && curPageN > 0); 
        
        if (searchForTextButton != null)
            searchForTextButton.setEnabled (curPageN > 0);

       
	  }

    

    private PropertyChangeSupport changes = new PropertyChangeSupport (this);

    public void addPropertyChangeListener (PropertyChangeListener listener)
    {
	    changes.addPropertyChangeListener (listener);
    }

    public void removePropertyChangeListener (PropertyChangeListener listener)
    {
	    changes.removePropertyChangeListener (listener);
    }

    public String getReportViewerName ()
    {
        return reportViewer == null ?
                   "" :
                   reportViewer.getName ();
    }

    public void setReportViewerName (String reportViewerName_)
    {
        System.out.println ("Setting 'reportViewerName' to \"" + reportViewerName_ + "\"");

        String reportViewerName = getReportViewerName ();

        if (!reportViewerName.equals (reportViewerName_))
        {
            if (reportViewer != null)
            {
                detachFromReportViewer ();
                updateButtons ();
            }

            reportViewer = findReportViewer (reportViewerName_, getFrame ());
            
            if (reportViewer != null)
            {
                attachToReportViewer ();
                updateButtons ();

                setHasToolBar (false);
                setReportName ("http://localhost/crweb/craze/adcont2s.rpt", null);
            }

	        changes.firePropertyChange ("reportViewerName", reportViewerName, reportViewerName_);
        }
    }


    private String exceptionText(PropertyVetoException e)
    {
        PropertyChangeEvent evt = e.getPropertyChangeEvent();
        Date myDate = new Date();
        return myDate.toString() + " Property Veto Exception Occurred!! Property: " + evt.getPropertyName()
            + " Old Value: " + evt.getOldValue() + " New Value: " + 
            evt.getNewValue();
    }
        
    public String getReportName ()
    {
        return reportViewer == null ?
                   "" :
                   reportViewer.getReportName ();
    }

    public boolean setReportName (String reportName_, TextField dlg)
    {
        System.out.println ("Setting 'reportName' to \"" + reportName_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setReportName (reportName_);
        }
        catch (Exception e)
        {
           String temp;
           if(e.getClass().getName() == "PropertyVetoException")
                temp = exceptionText((PropertyVetoException)e);
           else
                temp = e.getMessage();
           if(dlg != null)
            dlg.setText(temp);
            propertyWindow.eventList.add(temp, 0);
            isSuccessful = false;
        }
        updateButtons();
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

    public boolean setReportName (String reportName_)
    {
            return setReportName(reportName_, null);
    }
    
    public String getLanguage ()
    {
        return reportViewer == null ?
                   "" :
                   reportViewer.getLanguage ();
    }

    public boolean setLanguage (String language_, TextField dlg)
    {
        System.out.println ("Setting 'language' to \"" + language_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setLanguage (language_);
        }
        catch (PropertyVetoException e)
        {
              dlg.setText(exceptionText(e));
              isSuccessful = false;
        }
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }
    
    public boolean setPromptOnRefresh (boolean language_, TextField dlg)
    {
        System.out.println ("Setting 'promptOnRefresh' to \"" + language_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setPromptOnRefresh (language_);
        }
        catch (PropertyVetoException e)
        {
              dlg.setText(exceptionText(e));
              isSuccessful = false;
        }
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

public boolean getPromptOnRefresh ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getPromptOnRefresh ();
    }

public boolean setSelectionFormula (String language_, TextField dlg)
    {
        System.out.println ("Setting 'Selection Formula' to \"" + language_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setSelectionFormula(language_);
        }
        catch (PropertyVetoException e)
        {
              dlg.setText(exceptionText(e));
              isSuccessful = false;
        }
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

    public String getSelectionFormula ()
    {
        return reportViewer == null ?
                   null :
                   reportViewer.getSelectionFormula ();
    }

public boolean setReportParameter (String language_, TextField dlg)
    {
        System.out.println ("Setting 'ReportParameter' to \"" + language_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setReportParameter(language_);
        }
        catch (PropertyVetoException e)
        {
              dlg.setText(exceptionText(e));
              isSuccessful = false;
        }
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

    public String getReportParameter ()
    {
        return reportViewer == null ?
                   null :
                   reportViewer.getReportParameter ();
    }


    public boolean getHasToolBar ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getHasToolBar ();
    }

    public boolean setHasToolBar (boolean hasToolBar_, TextField dlg)
    {
        System.out.println ("Setting 'hasToolBar' to \"" + hasToolBar_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setHasToolBar (hasToolBar_);
        }
        catch (PropertyVetoException e)
        {
             if(dlg != null)
                 dlg.setText(exceptionText(e));
             isSuccessful = false;
        }   
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

    public boolean setHasToolBar (boolean hasToolBar_)
    {
        return setHasToolBar(hasToolBar_, null);
    }
    public boolean isPrintingPossible ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.isPrintingPossible ();
    }

    public boolean isExportingPossible ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.isExportingPossible ();
    }
    public boolean getPrintingPossible ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getPrintingPossible ();
    }

    public boolean getHasPrintButton ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getHasPrintButton ();
    }
    
    public boolean getHasExportButton ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getHasExportButton ();
    }

    public boolean setHasExportButton (boolean hasExportButton_, TextField dlg)
    {
        System.out.println ("Setting 'hasExportButton' to \"" + hasExportButton_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setHasExportButton (hasExportButton_);
        }
        catch (PropertyVetoException e)
        {
            String temp = exceptionText(e);
            if(dlg != null)
                dlg.setText(temp);
            propertyWindow.eventList.add(temp, 0);
            isSuccessful = false;
        }
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

    public boolean getCanDrillDown ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getCanDrillDown ();
    }

    public boolean setCanDrillDown (boolean canDrillDown_, TextField dlg)
    {
        System.out.println ("Setting 'canDrillDown' to \"" + canDrillDown_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setCanDrillDown (canDrillDown_);
        }
        catch (PropertyVetoException e)
        {
            String temp = exceptionText(e);
            if(dlg != null)
                dlg.setText(temp);
            propertyWindow.eventList.add(temp, 0);
            isSuccessful = false;
        }
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

    public boolean getHasTextSearchControls ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getHasTextSearchControls ();
    }

    public boolean setHasTextSearchControls (boolean hasTextSearchControls_, TextField dlg)
    {
        System.out.println ("Setting 'hasTextSearchControls' to \"" + hasTextSearchControls_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setHasTextSearchControls (hasTextSearchControls_);
        }
        catch (PropertyVetoException e)
        {
            String temp = exceptionText(e);
            if(dlg != null)
                dlg.setText(temp);
            propertyWindow.eventList.add(temp, 0);
            isSuccessful = false;
        }
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

public boolean setHasPrintButton (boolean hasPrintButton_, TextField dlg)
    {
        System.out.println ("Setting 'hasPrintButton' to \"" + hasPrintButton_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setHasPrintButton (hasPrintButton_);
        }
        catch (PropertyVetoException e)
        {
            String temp = exceptionText(e);
            if(dlg != null)
                dlg.setText(temp);
            propertyWindow.eventList.add(temp, 0);
            isSuccessful = false;
        }
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

    public boolean getHasRefreshButton ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getHasRefreshButton ();
    }

    public boolean setHasRefreshButton (boolean hasRefreshButton_, TextField dlg)
    {
        System.out.println ("Setting 'hasRefreshButton' to \"" + hasRefreshButton_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setHasRefreshButton (hasRefreshButton_);
        }
        catch (PropertyVetoException e)
        {
            String temp = exceptionText(e);
            if(dlg != null)
                dlg.setText(temp);
            propertyWindow.eventList.add(temp, 0);
            isSuccessful = false;
        }
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

    public boolean getHasGroupTree ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getHasGroupTree ();
    }

    public boolean setHasGroupTree (boolean hasGroupTree_, TextField dlg)
    {
        System.out.println ("Setting 'hasGroupTree' to \"" + hasGroupTree_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setHasGroupTree (hasGroupTree_);
        }
        catch (PropertyVetoException e)
        {
            String temp = exceptionText(e);
            if(dlg != null)
                dlg.setText(temp);
            propertyWindow.eventList.add(temp, 0);
            isSuccessful = false;
        }
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

    public boolean getShowGroupTree ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getShowGroupTree ();
    }

    public boolean setShowGroupTree (boolean showGroupTree_, TextField dlg)
    {
        System.out.println ("Setting 'showGroupTree' to \"" + showGroupTree_ + "\"");

        if (reportViewer == null)
            return false;
        boolean isSuccessful = true;
        try
        {
            reportViewer.setShowGroupTree (showGroupTree_);
        }
        catch (PropertyVetoException e)
        {
            String temp = exceptionText(e);
            if(dlg != null)
                dlg.setText(temp);
            propertyWindow.eventList.add(temp, 0);
            isSuccessful = false;
        }
        return isSuccessful;
	    // Fire property change when the Report Viewer notifies us.
    }

    public int getCurrentPageNumber ()
    {
        return reportViewer == null ?
                   1 :
                   reportViewer.getCurrentPageNumber ();
    }

    public int getLastPageNumber ()
    {
        return reportViewer == null ?
                   1 :
                   reportViewer.getLastPageNumber ();
    }

    public boolean isLastPageNumberKnown ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.isLastPageNumberKnown ();
    }

    public boolean getLastPageNumberKnown ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getLastPageNumberKnown ();
    }

    public String getCurrentViewName ()
    {
        return reportViewer == null ?
                   "" :
                   reportViewer.getCurrentViewName ();
    }

    public boolean getCanCloseCurrentView ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getCanCloseCurrentView ();
    }

    public boolean isBusy ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.isBusy ();
    }

    public boolean getBusy ()
    {
        return reportViewer == null ?
                   false :
                   reportViewer.getBusy ();
    }

    public String getSearchText ()
    {
        return reportViewer == null ?
                   "" :
                   reportViewer.getSearchText ();
    }

    public String getCurrentMessage ()
    {
        return reportViewer == null ?
                   "" :
                   reportViewer.getCurrentMessage ();
    }

    public String getCurrentTip ()
    {
        return reportViewer == null ?
                   "" :
                   reportViewer.getCurrentTip ();
    }

    // 'PropertyChangeListener' methods:

    public void propertyChange (PropertyChangeEvent event)
    {
        String propertyName = event.getPropertyName ();
        String temp;
       // if (propertyName.equals ("currentMessage") || propertyName.equals ("currentTip"))
         //   return;
        Date myDate = new Date();
        
       temp =  myDate.toString() + " Property: " + propertyName + " was changed from " +
                            event.getOldValue () + " to " + event.getNewValue ();
        propertyWindow.eventList.add(temp, 0);    
        propertyWindow.lastEvent.setText(temp);
        changes.firePropertyChange (propertyName, event.getOldValue (), event.getNewValue ());
    
        if (propertyName.equals ("searchText"))
            searchString = (String) event.getNewValue ();

        updateButtons ();
    }

    // 'ViewChangeListener' methods:

    public void viewOpened (ViewChangeEvent event)
    {
         String temp;
         Date myDate = new Date();
         temp = myDate.toString() + " View Opened Event: View = " + event.getViewName ();
         propertyWindow.lastEvent.setText(temp);
        propertyWindow.eventList.add(temp, 0);    
    }
    
    public void viewActivated (ViewChangeEvent event)
    {
        String temp;
        Date myDate = new Date();
        temp = myDate.toString() +  " View Activated Event: View = " + event.getViewName ();
        propertyWindow.lastEvent.setText(temp);
        propertyWindow.eventList.add(temp, 0);    
    }
    
    public void viewClosed (ViewChangeEvent event)
    {   
        String temp;
        Date myDate = new Date();
        temp = myDate.toString() + " View Closed Event: View = " + event.getViewName ();
        propertyWindow.lastEvent.setText(temp);
        propertyWindow.eventList.add(temp, 0);    
    }

    // 'ServerRequestListener' methods:

    public void requestStarted (ServerRequestEvent event)
    {
        String temp;
        Date myDate = new Date();
        temp = myDate.toString() + " Started server request Event: " +
                            event.getServerURL ().toString () + "&" + event.getParameters ();
       propertyWindow.lastEvent.setText(temp); 
        propertyWindow.eventList.add(temp, 0);                 
    }
    
    public void requestEnded (ServerRequestEvent event)
    {
        String temp;
        Date myDate = new Date();
        temp = myDate.toString() + " Ended server request Event: " +
                            event.getServerURL ().toString () + "&" + event.getParameters ();
		propertyWindow.lastEvent.setText(temp);
		propertyWindow.eventList.add(temp, 0);     
		updateButtons();
    }
    RVTesterProperty propertyWindow;
	//{{DECLARE_CONTROLS
	java.awt.Panel labelPanel;
	java.awt.Button showViewerProperty;
	java.awt.Panel controlsPanel;
	java.awt.Button closeViewButton;
	java.awt.Button firstPageButton;
	java.awt.Button prevPageButton;
	java.awt.TextField pageField;
	java.awt.Button goToPageButton;
	java.awt.Button nextPageButton;
	java.awt.Button lastPageButton;
	java.awt.Button stopButton;
	java.awt.Button refreshButton;
	java.awt.Button printButton;
	java.awt.Button exportButton;
	java.awt.Button searchForTextButton;
	java.awt.TextField searchField;
	java.awt.Panel reportPanel;
	com.seagatesoftware.img.ReportViewer.ReportViewerBean reportViewer;
	//}}

    String searchString = "";

	class SymMouse implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == showViewerProperty)
				showViewerProperty_MouseClick(event);
		}
	}

	void showViewerProperty_MouseClick(java.awt.event.ActionEvent event)
	{
		
		
		propertyWindow.setVisible (true);
		showViewerProperty.setEnabled(false);
		
	}

    
	
}
